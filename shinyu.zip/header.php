<!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo wp_is_mobile() ? 'mobile' : 'pc'; ?>">
	<head>
		<meta charset="<?php bloginfo('charset'); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11">
		<meta name="theme-color" id="theme-color" content="#0f4b81">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="msapplication-TileColor" content="#0f4b81">
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
		<div class="wrapper">
			<header class="header site-header">
				<div class="container d-flex">
					<a href="<?php echo esc_url(home_url('/')); ?>" class="site-branding" aria-label="">
						<img src="<?php echo content_url('uploads/2020/12/logo.png') ?>" alt="">
					</a>
					<nav class="site-navigation">
						<ul>
							<li class="navigation-item<?php if (get_query_var('transaction') === 'sell') echo ' is-active'; ?>" data-transaction="sell">
								<a href="<?php echo get_permalink(PAGE_ID_SEARCH); ?>?transaction=sell"><?php pll_e('Buy'); ?></a>
							</li>
							<li class="navigation-item<?php if (get_query_var('transaction') === 'rent') echo ' is-active'; ?>" data-transaction="rent">
								<a href="<?php echo get_permalink(PAGE_ID_SEARCH); ?>?transaction=rent"><?php pll_e('Rent'); ?></a>
							</li>
							<li class="navigation-item<?php if (is_post_type_archive('promotion')) echo ' is-active'; ?>">
								<a href="<?php echo get_post_type_archive_link('promotion'); ?>"><?php _e('Promotion', THEME_SLUG); ?></a>
							</li>
							<li class="navigation-item<?php if (is_page('post-property')) echo ' is-active'; ?>">
								<a href="<?php echo get_permalink(PAGE_ID_POST_PROPERTY); ?>"><?php pll_e('Post Property'); ?></a>
							</li>
						</ul>
					</nav>
					<div class="dropdown is-hoverable currency-switcher">
						<div class="dropdown-trigger">
							<span><?php echo CURRENCY; ?></span>
						</div>
						<div class="dropdown-menu" id="dropdown-menu4" role="menu">
							<div class="dropdown-content">
								<?php
									$currencies = get_all_currencies();
									foreach ($currencies as $currency) {
										if ($currency['code'] !== CURRENCY ) { ?>
										<a class="dropdown-item" href="#" data-code="<?php echo $currency['code']; ?>"><?php echo $currency['code']; ?></a>
									<?php }
									}
								?>
							</div>
						</div>
					</div>
					<div class="dropdown is-hoverable languages-switcher">
						<div class="dropdown-trigger">
							<img src="<?php echo STATIC_URI . '/flag/' . pll_current_language('slug') . '.svg' ?>" alt="">
						</div>
						<div class="dropdown-menu" id="dropdown-menu4" role="menu">
							<div class="dropdown-content">
								<?php echo languages_switcher(); ?>
							</div>
						</div>
					</div>
					<div class="header-end d-flex">
						<!-- <div class="header-compare">
							<?php shinyu_icon('compare'); ?>
						</div> -->
						<div class="hamburger-menu">
							<div class="hamburger">
								<div class="hamburger-box">
									<div class="hamburger-inner"></div>
								</div>
							</div>
							<div class="rippleJS"></div>
						</div>
						<div class="header-account">
							<div class="account-icon"><?php shinyu_icon('user-2'); ?></div>
						</div>
					</div>
				</div>
			</header>
			<div class="fullscreen-navigation">
				<div class="fullscreen-navigation-body">
					<div class="container d-block d-lg-none">

					</div>
					<div class="container d-none d-lg-block">
						<div class="columns">
							<div class="column is-3">
								<h3><a href="<?php echo get_permalink(PAGE_ID_ABOUT); ?>"><?php echo get_the_title(PAGE_ID_ABOUT); ?></a></h3>
								<ul>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_ABOUT); ?>?section=shinyu-value">Shinyu Value</a>
									</li>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_ABOUT); ?>?section=team"><?php pll_e('Our Team'); ?></a>
									</li>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_ABOUT); ?>?section=developer"><?php pll_e('The Developer'); ?></a>
									</li>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_ABOUT); ?>?section=partner"><?php pll_e('Our Partners'); ?></a>
									</li>
								</ul>
							</div>
							<div class="column is-3">
								<h3><a href="<?php echo get_post_type_archive_link('service'); ?>"><?php pll_e('Our Services') ?></a></h3>
								<ul class="our-services">
									<?php
										$args = [
											'post_type'          => 'service',
											'posts_per_page'     => 9,
											'post_status'        => 'publish',
										];

										$the_query = new WP_Query( $args );

										if ($the_query->have_posts()) :
											while ($the_query->have_posts()) : $the_query->the_post(); ?>
												<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
											<?php endwhile;
											wp_reset_postdata();
										endif;
									?>
								</ul>
							</div>

							<div class="column is-3">
								<h3>แพคเกจบริการอื่นๆ</h3>
								<ul>
									<li>
										<a href="#">บริหารและจัดการห้อง</a>
									</li>
									<li>
										<a href="#">ภาษีที่ดินและสิ่งปลูกสร้าง</a>
									</li>
									<li>
										<a href="#">ชำระค่ามัดจำห้อง</a>
									</li>
									<li>
										<a href="#">บริการตรวจรับห้อง</a>
									</li>
								</ul>
							</div>

							<div class="column is-3">
								<h3>ชินยู อคาเดมี่</h3>
								<ul>
									<li><a href="#">คอร์สเอเจ้นท์คอนโดเงินล้านมืออาชีพ</a></li>
								</ul>
							</div>
						</div>

						<div class="columns columns-2">
							<div class="column is-3">
								<h3>เครื่องมือ</h3>
								<ul>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_CALCULATOR); ?>">
											<?php echo get_the_title(PAGE_ID_CALCULATOR); ?>
										</a>
									</li>
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_STATISTICS); ?>">
											<?php echo get_the_title(PAGE_ID_STATISTICS); ?>
										</a>
									</li>
									<!-- <li>
										<a href="#">Foreigners’ Guide</a>
									</li> -->
									<li>
										<a href="<?php echo get_permalink(PAGE_ID_COMPARE); ?>">
											<?php echo get_the_title(PAGE_ID_COMPARE); ?>
										</a>
									</li>
								</ul>
							</div>
							
							<div class="column is-3">
								<h3>ข่าวและบทความ</h3>
								<ul>
									<?php $terms = get_terms('news_cat');
										if (!empty($terms) && !is_wp_error($terms)) {
											foreach ($terms as $term) { ?>
												<li>
													<a href="<?php echo get_term_link($term->term_id); ?>"><?php echo $term->name ?></a>
												</li>
											<?php }
										} ?>
								</ul>
							</div>

							<div class="column is-3">
								<h3>ติดต่อเรา</h3>
								<ul>
									<li><a href="<?php echo get_permalink(PAGE_ID_CONTACT); ?>"><?php echo get_the_title(PAGE_ID_CONTACT); ?></a></li>
									<li><a href="<?php echo get_permalink(PAGE_ID_SITEMAP) ?>"><?php echo get_the_title(PAGE_ID_SITEMAP); ?></a></li>
								</ul>
							</div>

							<div class="column is-3">
								<ul class="social no-effect">
									<li>
										<div class="b-tooltip is-danger is-top is-medium is-square">
											<div class="tooltip-content">Facebook</div>
											<div class="tooltip-trigger">
												<a href="<?php the_field('social_facebook_url', 'option'); ?>" target="_blank">
													<?php shinyu_icon('facebook-2'); ?>
												</a>
											</div>
										</div>
									</li>
									<li>
										<div class="b-tooltip is-danger is-top is-medium is-square">
											<div class="tooltip-content">Line</div>
											<div class="tooltip-trigger">
												<a href="<?php the_field('social_line_url', 'option'); ?>" target="_blank">
													<?php shinyu_icon('line'); ?>
												</a>
											</div>
										</div>
									</li>
									<li>
										<div class="b-tooltip is-danger is-top is-medium is-square">
											<div class="tooltip-content">Instagram</div>
											<div class="tooltip-trigger">
												<a href="<?php the_field('social_instagram_url', 'option'); ?>" target="_blank">
													<?php shinyu_icon('instagram'); ?>
												</a>
											</div>
										</div>
									</li>
									<li>
										<div class="b-tooltip is-danger is-top is-medium is-square">
											<div class="tooltip-content">Facebook Messenger</div>
											<div class="tooltip-trigger">
												<a href="<?php the_field('social_messenger_url', 'option'); ?>" target="_blank">
													<?php shinyu_icon('messenger'); ?>
												</a>
											</div>
										</div>
									</li>
									<li>
										<div class="b-tooltip is-danger is-top is-medium is-square">
											<div class="tooltip-content">Youtube</div>
											<div class="tooltip-trigger">
												<a href="<?php the_field('social_youtube_url', 'option'); ?>" target="_blank">
													<?php shinyu_icon('youtube-2'); ?>
												</a>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="fullscreen-navigation-footer">
					<div class="container d-flex justify-content-between">
						<div class="d-flex">
							<p>© 2021 Shinyu Real Estate Co.,Ltd. All Rights Reserved.</p>
							<ul class="no-effect">
								<li><a href="#">Terms and Conditions</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<div>Member of Thailand Real Estate Broker Association</div>
					</div>
				</div>
			</div>
