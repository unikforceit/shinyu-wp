<?php get_header(); ?>
  <section class="search-bar is-relative"><search-bar></search-bar></section>
  <section class="page-header">
    <div class="container">
      <h1 class="page-title"><?php the_title(); ?></h1>
      <?php the_breadcrumb(); ?>
    </div>
  </section><!-- .page-header -->
	<main class="main-content">
    <div class="container">
      <?php if (have_posts()) : ?>
        <?php while(have_posts()) : the_post(); ?>
          <div class="single-news-image"><?php the_post_thumbnail('large'); ?></div>
          <div class="single-news-content">
            <div class="the-content"><?php the_content(); ?></div>
            <?php social_share('แชร์บทความนี้ :', get_the_permalink()); ?>
          </div>
        <?php endwhile; ?>
      <?php endif ?>
    </div>

    <?php 
      $args = array(
        'post_type'          => 'news',
        'posts_per_page'     => 3,
        'post_status'        => 'publish',
        'orderby'            => 'rand',
        'post__not_in'       => [get_the_ID()],
        // 'order'              => 'ASC'
      );
      $the_query = new WP_Query( $args );

      if ($the_query->have_posts()) : ?>
        <section class="related-news container">
          <h3 class="related-news-title">บทความน่าสนใจ</h3>
          <div class="columns is-multiline mt-0 mb-0">
            <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
              <div class="column is-4 news-col">
                <div class="news-item card">
                  <a class="card-image" href="<?php the_permalink(); ?>">
                    <?php
                      if (has_post_thumbnail()) : echo get_the_post_thumbnail(get_the_ID(), 'thumb-news');
                      else : echo "<img src='https://via.placeholder.com/358x210/FFFF00/000000'>";
                      endif;
                    ?>
                  </a>
                  <div class="news-content card-content">
                    <h4 class="news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <div class="news-excerpt"><?php echo get_the_excerpt(); ?></div>
                    <a class="news-read" href="<?php the_permalink(); ?>">อ่านต่อ</a>
                  </div>
                </div>
              </div>
            <?php endwhile;
            wp_reset_postdata(); ?>
          </div>
        </section>
      <?php endif;
    ?>
  </main>
<?php get_footer(); ?>
