
<?php
/**
 * Template Name: Search
 */
get_header(); ?>
	<main class="main-content"><search></search></main>
<?php get_footer(); ?>