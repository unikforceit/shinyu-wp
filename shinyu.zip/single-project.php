<?php get_header(); ?>
  <section class="search-bar is-relative"><search-bar></search-bar></section>
	<main class="main-content">
  <?php if (have_posts()) : ?>
    <?php while(have_posts()) : the_post();
      $badge            = [];
      $area             = [];
      $location         = [];
      $facilities       = [];
      $project_id       = get_field('room_project');
      $developer        = wp_get_post_terms($project_id, 'project_developer');
      $locations        = wp_get_post_terms($project_id, 'project_location');
      $room_facility    = wp_get_post_terms(get_the_ID(), 'room_facility');
      $project_facility = wp_get_post_terms($project_id, 'project_facility');
      $tags             = wp_get_post_terms(get_the_ID(), 'room_tag');
      $areas            = wp_get_post_terms($project_id, 'project_area');
      $galleries        = get_field('project_gallery', false, false);
      $price_sell       = price(get_field('room_sell_price'), 'THB');
      $price_rent       = price(get_field('room_rent_price'), 'THB');
      $project_no          = get_field('room_project_no');
      $facilities       =  $room_facility + $project_facility;

      $location_lat     = get_field('project_location_lat');
      $location_lng     = get_field('project_location_lng');

      // if ($room_facility) {
      //   foreach ($room_facility as $facility) {
      //     $facilities[] = $facility->name;
      //   }
      // }
  
      // if ($project_facility) {
      //   foreach ($project_facility as $facility) {
      //     $facilities[] = $facility->name;
      //   }
      // }

      $field_bedrooms = field_bedrooms(get_locale());
      $field_bathrooms = field_bathrooms(get_locale());

      if ($tags) {
        foreach ($tags as $tag) {
          $badge[] = $tag->description;
        }
      }

      if ($areas) {
        foreach ($areas as $item) {
          $area[] = $item->name;
        }
      }

      if ($locations) {
        foreach ($locations as $item) {
          $location[] = $item->name;
        }
      }

      array_unshift($galleries, get_post_thumbnail_id());

      if ($galleries) : ?>
      <section class="project-gallery" id="gallery">
        <nav class="navigation scrollspy">
          <div class="navigation-inner">
            <ul class="container d-flex">
              <li><a href="#gallery" class="active"><?php pll_e('Gallery'); ?><div class="rippleJS"></div></a></li>
              <li><a href="#detail">รายละเอียด<div class="rippleJS"></div></a></li>
              <li><a href="#facilities"><?php pll_e('Facilities'); ?><div class="rippleJS"></div></a></li>
              <li><a href="#location"><?php pll_e('Location'); ?><div class="rippleJS"></div></a></li>
              <li><a href="#recommended-projects"><?php pll_e('Recommended Units'); ?><div class="rippleJS"></div></a></li>
              <li><a href="#register"><?php pll_e('Register'); ?><div class="rippleJS"></div></a></li>              
            </ul>
          </div>
        </nav>
        <div class="swiper-container gallery-swiper-container">
          <div class="swiper-wrapper">
            <?php foreach ($galleries as $gallery) : ?>
              <?php
                $sizes = wp_get_attachment_image_src($gallery, 'large');
                $detection = 'horizontal';
                if ($sizes[1] < $sizes[2]) $detection = 'vertical';
              ?>
              <div class="swiper-slide">
                <div class="container">
                  <a  data-fslightbox class="project-gallery-item glightbox" href="<?php echo wp_get_attachment_image_url($gallery, '1536x1536'); ?>">
                    <?php echo wp_get_attachment_image($gallery, 'project-gallery', null, ['class' => $detection]); ?>
                  </a>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="container">
            <div class="project-gallery-control d-flex align-items-center">
              <div class="project-gallery-pagination"></div>
              <button class="button prev"></button>
              <button class="button next"></button>
            </div>
          </div>
        </div>
      </section>
      <?php endif; ?>

      <section class="project-body" id="detail">
        <div class="project-herder">
          <div class="container h-100">
            <div class="d-flex align-items-center justify-content-between h-100">
              <div class="project-title-wrap">
                <h1 class="project-title"><?php the_title(); ?></h1>
                <?php if ($project_no) : ?>
                <small class="project-no"><?php echo pll__('Unit') . ' ' . $project_no; ?> </small>
                <?php endif; ?>
              </div>
              <div class="project-single-price h-100<?php if ($price_sell && $price_rent) echo ' is-multiprice'; ?>">
                <?php if ($price_rent) : ?>
                <bdi class="d-flex align-items-center rent">
                  <div>
                    <small class="d-block pb-1">เช่า/เดือน</small> <span class="d-block"> THB <?php echo number_format($price_rent); ?></span>
                  </div>
                </bdi>
                <?php endif; ?>
                <?php if ($price_sell) : ?>
                <bdi class="d-flex align-items-center sell">
                  <div>
                    <small class="d-block pb-1">ขาย</small> <span class="d-block"> THB <?php echo number_format($price_sell); ?></span>
                  </div>
                </bdi>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <div class="project-content">
          <div class="container">
            <?php the_content(); ?>
          </div>
        </div>
      </section>
      

      <?php if ($facilities) : ?>
      <section class="project-facility" id="facilities">
        <div class="container">
          <h3 class="has-text-primary"><?php pll_e('Facilities') ?></h3>
          <ul class="project-facility-list">
            <?php foreach ($facilities as $facility) : ?>
              <li class="project-facility-item d-flex"><?php shinyu_icon('tick'); ?> <?php echo $facility->name; ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </section>
      <?php endif ?>

      <section class="project-map" id="location" data-lat="<?php echo $location_lat; ?>" data-lng="<?php echo $location_lng; ?>">
        <div class="container">
          <h3 class="has-text-primary"><?php pll_e('Location') ?></h3>
          <div class="columns is-gapless">
            <div class="column"><div class="project-google-map"></div></div>
            <div class="column"><div class="project-google-pano"></div>  </div>
          </div>     
        </div>
      </section>

      <section class="project-recommended" id="recommended-projects">
        <div class="container">
          <h3 class="has-text-primary">ยูนิตแนะนำ</h3>
          <div class="project-recommended-list"><project-recommended></project-recommended></div>
        </div>
      </section>

      <section class="project-registration" id="register">
        <div class="container">
          <h3 class="has-text-primary has-text-centered">ติดต่อตัวแทนฝ่ายขาย</h3>
          <div class="project-registration-form"><project-registration-form></project-registration-form></div>
        </div>
      </section>
    <?php endwhile; ?>
  <?php endif ?>
  </main>
<?php get_footer(); ?>
