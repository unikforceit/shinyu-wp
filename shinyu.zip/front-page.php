<?php get_header(); ?>
  <section class="slideshow">
    <div class="swiper-container slideshow-swiper-container">
      <div class="swiper-wrapper">
        <?php if (have_rows('_page_home_slideshow')) : ?>
          <?php while(have_rows('_page_home_slideshow')): the_row(); ?>
            <?php
              $image_url = wp_get_attachment_image_url(get_sub_field('image'), 'slideshow');
            ?>
            <div class="swiper-slide slideshow-item d-flex justify-content-center align-items-center text-center">
              <div class="slideshow-content d-flex justify-content-center align-items-center text-center">
                <div class="slideshow-content-inner">
                  <h2 class="slideshow-title"><?php the_sub_field('title') ?></h2>
                  <p class="slideshow-description"><?php the_sub_field('description') ?></p>
                </div>
              </div>
              <img src="<?php echo $image_url; ?>">
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
      <div class="slideshow-navigation d-flex justify-content-between">
        <!-- <button class="prev">Prev</button>
        <button class="next">Next</button> -->
      </div>
      <div class="container">
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </section>
  <section class="search-box">
    <search-box></search-box>
  </section>
  <main class="main-content">
    <section class="unit-special">
      <div class="container">
        <h2 class="text-center">ยูนิตคัดพิเศษ <small>ชินยู นำมาให้คุณได้เลือกก่อนใคร</small></h2>
        <div class="unit-special-app"><unit-special></unit-special></div>
      </div>
    </section>

    <section class="shinyu-channel" style="background-image: url(<?php echo content_url('uploads/2020/12/shinyu-channel-bg.jpg'); ?>)">
      <div class="container">
        <h2 class="section-title">SHINYU CHANNEL</h2>
        <p class="section-description">อีกหนึ่งช่องทางที่คุณจะได้ติดตามเรื่องราวอสังหาฯ และเรียนรู้เทคนิคอีกมากมาย ติดตามเราได้ที่นี่</p>
        <div class="columns">
          <?php
            $args = [
              'post_type'          => 'video',
              'posts_per_page'     => 5,
              'post_status'        => 'publish',
              'order'              => 'DESC',
            ];

            $i = 0;
            $big = '';
            $small = '';

            $the_query = new WP_Query( $args );

            if ($the_query->have_posts()) :
              while ($the_query->have_posts()) : $the_query->the_post();
                $i++; 

                if ($i === 1) :
                  $big .= '<a class="media big d-block glightbox" href="'. get_field('_video_url') .'">';
                  $big .= '<figure class="image">';
                  $big .= '<img src="'. get_the_post_thumbnail_url(get_the_ID(), 'large') .'">';
                  $big .= '</figure>'; 
                  $big .= '<div class="media-content">';
                  $big .= '<h4 class="pt-4">'. get_the_title() .'</h4>';                      
                  $big .= '</div>';
                  $big .= '</a>';
                else : 
                  $small .= '<a class="media glightbox" href="'. get_field('_video_url') .'">';
                  $small .= '<div class="media-left">';
                  $small .= '<figure class="image">';
                  $small .= '<img src="'. get_the_post_thumbnail_url(get_the_ID(), 'thumb-video') .'">';
                  $small .= '</figure>';                  
                  $small .= '</div>';
                  $small .= '<div class="media-content">';
                  $small .= '<h4>'. get_the_title() .'</h4>';                      
                  $small .= '</div>';                                 
                  $small .= '</a>';
                endif;

              endwhile;
              wp_reset_postdata();
            endif;
          ?>
          <div class="column is-7"><?php echo $big; ?></div>
          <div class="column is-5">
            <?php echo $small; ?>
            <a class="button is-fullwidth mt-5" href="https://www.youtube.com/channel/UCL3QLc5C06VxE6zQvqAwuCw" target="_blank">SHINYU YOUTUBE CHANNEL</a>
          </div>
        </div>
      </div>
    </section>

    <section class="project-presale">
      <div class="container">
        <h2 class="section-title text-center">โครงการ Pre - Sale</h2>
        <p class="section-description text-center">ชินยู คัดสรรโครงการคุณภาพนำมาให้คุณได้เลือกก่อนใคร พร้อมโปรโมชั่นพิเศษสำหรับคุณ</p>
        <?php if (have_rows('_page_home_project')) : ?>
          <?php $i = 0; ?>
          <?php while (have_rows('_page_home_project')) : the_row(); ?>
            <?php $images = get_sub_field('gallery', false, false); ?>
            <div class="project-presale-item">
              <div class="columns is-gapless<?php if ($i % 2 != 0) echo ' is-flex-direction-row-reverse' ?>">
                <div class="column is-6">
                  <div class="project-presale-gallery">
                    <?php if ($images ) : ?>
                      <div class="swiper-container project-swiper-container">
                        <div class="swiper-wrapper">
                          <?php foreach ($images as $image) : ?>
                            <div class="swiper-slide">
                              <div class="project-presale-gallery-item">
                                <?php echo wp_get_attachment_image($image, 'large'); ?>
                              </div>
                            </div>
                          <?php endforeach; ?>
                          <div class="swiper-pagination"></div>
                        </div>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="column is-6">
                  <div class="project-presale-content">
                    <h4 class="project-presale-title"><a href="<?php the_sub_field('link'); ?>"><?php the_sub_field('title'); ?></a></h4>
                    <small class="project-presale-developer">by <?php the_sub_field('developer'); ?></small>
                    <p class="project-presale-description"><?php the_sub_field('description'); ?></p>
                    <a href="<?php the_sub_field('link'); ?>" class="project-presale-price"><?php the_sub_field('price'); ?></a>
                  </div>
                </div>
              </div>
            </div>
            <?php $i++; ?>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </section>
  
    <section class="service">
      <div class="service-background"></div>
      <div class="container">
        <div class="service-inner">
          <h2 class="section-title text-center">บริการทั้งหมดของชินยู</h2>
          <p class="section-description text-center">Shinyu Real Estate คือเพื่อนสนิทที่ตอบโจทย์คุณ ด้วยความเชี่ยวชาญทางด้านการลงทุน <br> อสังหาริมทรัพย์ที่มีความเชี่ยวชาญ ทั้งตลาดในไทยและต่างประเทศ Shinyu Real Estate</p>
          <div class="columns is-multiline">
            <?php
              $args = [
                'post_type'          => 'service',
                'posts_per_page'     => 9,
                'post_status'        => 'publish',
                'order'              => 'DESC',
              ];

              $the_query = new WP_Query( $args );

              if ($the_query->have_posts()) :
                while ($the_query->have_posts()) : $the_query->the_post(); ?>
                  <div class="column is-4">
                    <div class="service-item card">
                      <a class="service-image card-image" href="<?php echo get_post_type_archive_link('service'); ?>">
                        <?php
                          if (has_post_thumbnail()) : echo get_the_post_thumbnail(get_the_ID(), 'thumb-news');
                          else : echo "<img src='https://via.placeholder.com/358x210/FFFF00/000000'>";
                          endif
                        ?>
                      </a>
                      <div class="service-content card-content">
                        <h4 class="service-title"><a href="<?php echo get_post_type_archive_link('service'); ?>"><?php the_title(); ?></a></h4>
                        <p class="service-description"><?php the_field('_service_description'); ?></p>
                      </div>
                    </div>
                  </div>
                <?php endwhile;
                wp_reset_postdata();
              endif;
            ?>
          </div>
        </div>
      </div>
    </section>

    <section class="news" style="background-image: url(<?php echo content_url('uploads/2020/12/news-bg.jpg'); ?>)">
      <div class="container">
        <h2 class="section-title text-center">ข่าวสารแวดวงอสังหาริมทรัพย์ <a href="<?php echo get_post_type_archive_link('news'); ?>">+</a></h2>
        <p class="section-description text-center">พบกับข่าวสารจากผู้เชี่ยวชาญด้านอสังหาริมทรัพยที่อัพเดทล่าสุด</p>
        <div class="swiper-container news-swiper-container">
          <div class="swiper-wrapper">
            <?php
              $args = [
                'post_type'          => 'news',
                'posts_per_page'     => 9,
                'post_status'        => 'publish',
                'order'              => 'DESC',
              ];

              $the_query = new WP_Query( $args );

              if ($the_query->have_posts()) :
                while ($the_query->have_posts()) : $the_query->the_post(); ?>
                  <div class="swiper-slide">
                    <div class="news-item card">
                      <a class="card-image" href="<?php the_permalink(); ?>">
                        <?php
                          if (has_post_thumbnail()) : echo get_the_post_thumbnail(get_the_ID(), 'thumb-news');
                          else : echo "<img src='https://via.placeholder.com/358x210/FFFF00/000000'>";
                          endif
                        ?>
                      </a>
                      <div class="news-content card-content">
                        <h4 class="news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                        <a class="news-read" href="<?php the_permalink(); ?>">อ่านเพิ่มเติม</a>
                      </div>
                    </div>
                  </div>
                <?php endwhile;
                wp_reset_postdata();
              endif;
            ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section>
    <section class="partner">
      <div class="container">
        <h2 class="section-title text-center">พาร์ทเนอร์คนสำคัญ</h2>
        <p class="section-description text-center">เพราะเราต้องคัดสรรสิ่งที่ดีที่สุดเพื่อลูกค้าของเรา</p>

        <div class="swiper-container partner-swiper-container">
          <div class="swiper-wrapper">
            <?php
              $args = [
                'post_type'          => 'partner',
                'posts_per_page'     => -1,
                'post_status'        => 'publish',
                'order'              => 'ASC',
              ];

              $the_query = new WP_Query( $args );

              if ($the_query->have_posts()) :
                while ($the_query->have_posts()) : $the_query->the_post(); ?>
                <div class="swiper-slide text-center">
                  <a href="<?php the_field('_partner_url'); ?>" target="_blank" class="partner-item d-block"><?php the_post_thumbnail('thumbnail') ?></a>
                </div>
                <?php endwhile;
                wp_reset_postdata();
              endif;
            ?>
          </div>
          <div class="container">
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php get_footer(); ?>