
<?php
/**
 * Template Name: Compare
 */
get_header(); ?>
  <section class="search-bar is-relative"><search-bar></search-bar></section>
  <section class="page-header minimal">
    <div class="container">
      <h1 class="page-title"><?php the_title(); ?></h1>
      <?php //the_breadcrumb(); ?>
    </div>
  </section><!-- .page-header -->
	<main class="main-content">
		<post-property></post-property>
	</main>
<?php get_footer(); ?>