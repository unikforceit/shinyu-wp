<?php
class Shinyu_Unit_Recommended_API {
  protected static $instance = null;

  public static function get_instance() {

    if ( !self::$instance ) {
      self::$instance = new Shinyu_Unit_Recommended_API();
    }
    return self::$instance;

  }

  public function __construct() {
    $this->hooks();
  }

  public function hooks() {
    add_action('rest_api_init', [$this , 'rest_api_init']);
  }

  public function rest_api_init() {
    register_rest_route('shinyu', '/unit/recommended', [
      'methods'  => 'GET',
      'args'     => ['lang'],
      'callback' => [$this, 'api']
    ]);

  }

  public function api($request) {
    $data = [];

    $args = [
      'post_type'          => 'room',
      'posts_per_page'     => 3,
      'post_status'        => 'publish',
      'orderby'            => 'rand',
      'order'              => 'ASC',
      'tax_query'          => [
        [
          'taxonomy' => 'room_tag',
          'field'    => 'id',
          'terms'    => 3803,
        ]
      ],
    ];

    $the_query = new WP_Query($args);
    
    return [
      'data' => unit_item($the_query),
      'status' => 200
    ];
  }
}

Shinyu_Unit_Recommended_API::get_instance();