<?php 
return [
  'buy'           => pll__('Buy'),
  'rent'          => pll__('Rent'),
  'lease'         => pll__('Lease'),
  'sales'         => pll__('Sales'),
  'month'         => pll__('Month'),
  'bedroom'       => pll__('Bedroom'),
  'bathroom'      => pll__('Bathroom'),
  'usable_area'   => pll__('Usable area'),
  'sqm'           => pll__('Sq.m.'),
  'search'        => [
    'sales'               => pll__('Sales'),
    'buy'                 => pll__('Buy'),
    'rent'                => pll__('Rent'),
    'search'              => pll__('Search'),
    'price'               => pll__('Price'),
    'keyword'             => pll__('Enter project name, location'),
    'bedroom'             => pll__('Bedroom'),
    'bathroom'            => pll__('Bathroom'),
    'latest_update'       => pll__('Latest update'),
    'price_low_to_high'   => pll__('Price: low to high'),
    'price_high_to_low'   => pll__('Price: high to low'),
    'any'                 => pll__('Any'),
  ]
];