			<section class="subscribe">
				<subscribe></subscribe>
			</section>
			<footer class="site-footer">
				<div class="container">
					<div class="columns">
						<div class="column">
							<ul class="is-primary">
								<li>
									<a href="<?php echo get_permalink(PAGE_ID_SEARCH); ?>?transaction=sell">ซื้อคอนโด</a>
								</li>
								<li>
									<a href="<?php echo get_permalink(PAGE_ID_SEARCH); ?>?transaction=rent">เช่าคอนโด</a>
								</li>
								<li>
									<a href="<?php echo get_permalink(PAGE_ID_POST_PROPERTY); ?>">ฝากขาย / ฝากเช่า</a>
								</li>
								<li>
									<a href="<?php echo get_post_type_archive_link('promotion'); ?>">โปรโมชั่น</a>
								</li>
								<li>
									<a href="<?php echo get_post_type_archive_link('service'); ?>">บริการอื่น ๆ</a>
								</li>
							</ul>
						</div>
						<div class="column">
							<h3>ทำเลน่าสนใจ</h3>
							<ul>
								<li><a href="#">ทำเลน่าสนใจโซนทองหล่อ</a></li>
								<li><a href="#">คอนโดทำเลรถไฟฟ้า</a></li>
								<li><a href="#">ยูนิตสุดท้ายก่อนปิดโครงการ</a></li>
								<li><a href="#">ยูนิตราคาต่ำกว่าตลาด</a></li>
							</ul>

							<h3>ติดตามเรา</h3>
							<ul class="social">
								<li>
									<div class="b-tooltip is-danger is-top is-medium is-square">
										<div class="tooltip-content">Facebook</div>
										<div class="tooltip-trigger">
											<a href="<?php the_field('social_facebook_url', 'option'); ?>" target="_blank">
												<?php shinyu_icon('facebook-2'); ?>
											</a>
										</div>
									</div>
								</li>
								<li>
									<div class="b-tooltip is-danger is-top is-medium is-square">
										<div class="tooltip-content">Line</div>
										<div class="tooltip-trigger">
											<a href="<?php the_field('social_line_url', 'option'); ?>" target="_blank">
												<?php shinyu_icon('line'); ?>
											</a>
										</div>
									</div>
								</li>
								<li>
									<div class="b-tooltip is-danger is-top is-medium is-square">
										<div class="tooltip-content">Instagram</div>
										<div class="tooltip-trigger">
											<a href="<?php the_field('social_instagram_url', 'option'); ?>" target="_blank">
												<?php shinyu_icon('instagram'); ?>
											</a>
										</div>
									</div>
								</li>
								<li>
									<div class="b-tooltip is-danger is-top is-medium is-square">
										<div class="tooltip-content">Facebook Messenger</div>
										<div class="tooltip-trigger">
											<a href="<?php the_field('social_messenger_url', 'option'); ?>" target="_blank">
												<?php shinyu_icon('messenger'); ?>
											</a>
										</div>
									</div>
								</li>
								<li>
									<div class="b-tooltip is-danger is-top is-medium is-square">
										<div class="tooltip-content">Youtube</div>
										<div class="tooltip-trigger">
											<a href="<?php the_field('social_youtube_url', 'option'); ?>" target="_blank">
												<?php shinyu_icon('youtube-2'); ?>
											</a>
										</div>
									</div>
								</li>
							</ul>
						</div>
						<div class="column train-station-column">
							<h3>การเดินทาง</h3>
							<div class="train-station"><train-station></train-station></div>
						</div>
						<div class="column pl-6">
							<h3>ผู้พัฒนา/แบรนด์</h3>
							<ul>
								<li><a href="#">อนันดา ดีเวลลอปเมินท์</a></li>
								<li><a href="#">เอ็ม คิว ดี ซี</a></li>
								<li><a href="#">เอพี พร็อพเพอร์ตี้</a></li>
								<li><a href="#">เมเจอร์ ดีเวลลอปเม้นท์</a></li>
								<li><a href="#">เอสซี่ แอสเสท คอร์ปอเรชั่น</a></li>
								<li><a href="#">ใบเบิล ดีเวลลอปเมนท์</a></li>
								<li><a href="#">ไรมอน แลนด์</a></li>
								<li><a href="#" class="viewall">ดูเพิ่มเติม</a></li>
							</ul>
						</div>
					</div>
				
					<div class="site-footer-copyright d-flex justify-content-between">
						<div class="d-flex">
							<p>Copyright 2021 Asian Business Partners (Thailand) Co.,Ltd. All rights reserved.</p>
							<ul>
								<li><a href="#">Terms and Conditions</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
						<div>Member of Thailand Real Estate Broker Association</div>
					</div>
				</div>
			</footer>
		</div>
		<div class="compare-selected"><compare-selected></compare-selected></div>
		<?php wp_footer(); ?>
	</body>
</html>