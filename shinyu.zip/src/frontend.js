import 'vanilla-ripplejs'
import './frontend.scss'
import common from './routes/common'
import home from './routes/home'
import search from './routes/search'
import postProperty from './routes/postProperty'
import singleRoom from './routes/room'
import singleProject from './routes/project'
import singleService from './routes/service'
import aboutUs from './routes/about'
import contactUs from './routes/contact'

import Router from './util/Router'

/**
 * Populate Router instance with DOM routes
 * @type {Router} routes - An instance of our router
 */
const routes = new Router({
  common,
  home,
  search,
  postProperty,
  singleRoom,
  singleProject,
  singleService,
  aboutUs,
  contactUs,
})

window.addEventListener('DOMContentLoaded', () => {
  routes.loadEvents()
})
