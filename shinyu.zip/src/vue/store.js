import Vue from 'vue'
import Vuex from 'vuex'
import VuexPersistence from 'vuex-persist'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    compareItems: [],
    loading: false,
  },
  mutations: {
    SET_COMPARE(state, data) {
      state.compareItems = data
    },
    SET_LOADING(state, data) {
      state.loading = data
    },
  },
  plugins: [new VuexPersistence().plugin],
})

export default store
