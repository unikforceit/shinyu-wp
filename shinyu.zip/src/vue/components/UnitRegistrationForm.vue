<template lang="pug">
  form
    b-field.mb-4(type="is-twitter" expanded)
      b-input(placeholder="ชื่อ - นามสกุล")

    b-field.mb-4(grouped expanded)
      b-field(type="is-twitter" expanded)
        b-input(type="tel" placeholder="เบอร์โทรศัพท์")

      b-field(type="is-twitter" expanded)
        b-input(type="email" placeholder="อีเมล")

    b-field.mb-4(type="is-twitter" expanded)
      b-input(type="textarea" placeholder="ข้อความ")

    .has-text-centered.pt-5
      b-button(type="is-primary" native-type="submit") ส่งข้อมูล

</template>