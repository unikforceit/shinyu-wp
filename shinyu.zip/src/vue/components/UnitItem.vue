<template lang="pug">
  .card.unit-item(:class="type")
    .card-image.unit-image
      a(
        :href="unit.link"
        :target="target"
      )
        img(:src="unit.image_url")

      .unit-badge.d-flex(v-if="unit.badge.length > 0")
        span.unit-badge-item(v-for="(item, index) in unit.badge" :key="index") {{ item }}

      .unit-action
        b-button(
          @click="addToCompare(unit.id)"
          :class="{ 'is-selected' : selected }"
        )
          b-tooltip(:label="selected ? 'Delete form compare' : 'Add to compare'" :square="true" type="is-danger")
            icon-compare

      ul.unit-for.d-flex
        li(v-for="(item, index) in unit.for" :key="")
          span(v-if="item === 'rent'" :class="item") {{ i18n.lease }}
          span(v-else :class="item") {{ i18n.sales }}

    .card-content.is-relative
      h4.unit-title
        a(
          :href="unit.link"
          :target="target"
        ) {{ unit.title }}
        small {{ unit.project }}
      
      .unit-location(v-if="unit.area")
        icon-location.unit-location-icon
        span {{ unit.area }}

      ul.unit-info
        li(v-if="unit.info.bedrooms")
          b-tooltip(:label="i18n.bedroom" :square="true" type="is-danger")
            icon-bed
            span {{ unit.info.bedrooms }}

        li(v-if="unit.info.bathrooms")
          b-tooltip(:label="i18n.bathroom" :square="true" type="is-danger")
            icon-bathroom
            span {{ unit.info.bathrooms }}

        li.area(v-if="unit.info.area_sqm ")
          b-tooltip(:label="i18n.usable_area" :square="true" type="is-danger")
            icon-fullscreen
            span {{ unit.info.area_sqm }} {{ i18n.sqm }}

    .card-footer.unit-footer
      .unit-price
        template(v-if="type")
          bdi.d-block(v-if="unit.price.rent && type === 'rent'").rent
            span {{ i18n.rent }} 
            span.currency-symbol  {{ currencyUnit }} 
            span {{ unit.price.rent | formatMoney }} / {{ i18n.month }} 

          bdi.d-block(v-if="unit.price.sell && type === 'sell'").sell
            span {{ i18n.buy }}
            span.currency-symbol  {{ currencyUnit }}
            span {{ unit.price.sell | formatMoney }}

        template(v-else)
          bdi.d-block(v-if="unit.price.rent").rent
            span {{ i18n.rent }}
            span.currency-symbol  {{ currencyUnit }} 
            span {{ unit.price.rent | formatMoney }} / {{ i18n.month }}  

          bdi.d-block(v-if="unit.price.sell").sell
            span {{ i18n.buy }}
            span.currency-symbol  {{ currencyUnit }}
            span {{ unit.price.sell | formatMoney }}
</template>

<script>
import _ from 'lodash/array'
import { mapState } from 'vuex'
import IconLocation from '../icons/Location'
import IconBed from '../icons/Bed'
import IconBathroom from '../icons/Bathroom'
import IconFullscreen from '../icons/Fullscreen'
import IconCompare from '../icons/Compare'
// this.$store.commit('SET_COMPARE', this.form)
export default {
  components: { IconLocation, IconBed, IconBathroom, IconFullscreen, IconCompare },
  data: () => ({
    i18n: SHINYU.i18n,
    currencyUnit: SHINYU.currency.unit,
  }),

  props: {
    unit: {
      type: Object,
      default: () => {}
    },
    type: {
      type: String,
      default: '',
    },
    target: {
      type: String,
      default: '_blank',
    }
  },

  computed: {
    ...mapState(['compareItems']),
    selected() {
      return this.compareItems.includes(this.unit.id)
    }
  },

  methods: {
    addToCompare(id){
      let items = this.compareItems
      let message = 'Add item to compare successfully'

      if (this.compareItems.includes(id)) {
        items = _.remove(items, (n) => {
          return n !== id
        })
        message = 'Delete item form compare successfully'
      } else {
        if (items.length > 3) {
          this.$buefy.dialog.confirm({
            title: 'Confirmation',
            message: 'คุณต้องการเพิ่มยูนิตนี้แทนยูนิตเปรียบเทียบล่าสุดหรือไม่?',
            onConfirm: () => {
              items = _.dropRight(items)
              items.push(id)
              this.$store.commit('SET_COMPARE', items)
              return
            }
          })
        } else {
          items.push(id)
        }
      }
      this.$store.commit('SET_COMPARE', items)
    }
  }
}
</script>
