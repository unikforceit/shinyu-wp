<template lang="pug">
  div
    b-collapse.card(:open="false" animation="slide" aria-id="mrt")
      button.button.is-primary.is-inverted(
        slot="trigger"
        slot-scope="props"
        aria-controls="mrt"
        :class="props.open ? 'is-active' : ''"
      ) MRT
      ul
        li(v-for="(item, index) in mrt" :key="index")
          a(href="#") {{ item }}

    b-collapse.card(animation="slide" aria-id="bts")
      button.button.is-primary.is-inverted(
        slot="trigger"
        slot-scope="props"
        herf="#"
        aria-controls="bts"
        :class="props.open ? 'is-active' : ''"
      ) BTS
      ul
        li(v-for="(item, index) in bts" :key="index")
          a(href="#") {{ item }}

</template>

<script>
export default {
  data: () => ({
    bts: ['สถานีพญาไท', 'สถานีราชเทวี', 'สถานีสยาม', 'สถานีชิดลม', 'สถานีเพลินจิต', 'สถานีพร้อมพงษ์'],
    mrt: ['สายสีน้ำเงิน', 'บางซื่อ', 'สวนจตุจักร', 'พหลโยธิน', 'ลาดพร้าว', 'ห้วยขวาง', 'พระราม 9'],
  })
}
</script>