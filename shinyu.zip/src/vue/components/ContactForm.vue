<template lang="pug">
  form
    h3.has-text-primary คุยกับเรา

    b-field.mb-4(type="is-twitter" expanded)
      b-input(placeholder="ชื่อ - นามสกุล")

    b-field.mb-4(grouped expanded)

      b-field(type="is-twitter" expanded)
        b-input(type="tel" placeholder="เบอร์โทรศัพท์")

      b-field(type="is-twitter" expanded)
        b-input(type="email" placeholder="อีเมล")

    b-field.mb-4(type="is-twitter" expanded)
      b-input(type="textarea" placeholder="ข้อความ")

    b-field.mb-0
      b-checkbox(
        v-model="subscribe"
        size="is-small"
      ) ฉันต้องการที่จะรับข่าวสารจากชินยู

    b-field
      b-checkbox(
        v-model="accept"
        size="is-small"
      ) การกดส่งข้อความนับเป็นการตกลงใน
         a  Privacy Policy 
         | และ 
         a Term & Condition

    .has-text-right.pt-5
      b-button(type="is-primary" native-type="submit" :disabled="!accept") ส่งข้อมูล

</template>

<script>
export default {
  data: () => ({
    subscribe: false,
    accept: false
  })
}
</script>
