<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11.44 20.76"><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M9.62,10.38,6.55,7.31.78,1.55a1.64,1.64,0,0,1-.3-.35A.5.5,0,0,1,.61.46,1.28,1.28,0,0,1,1.34.41c.11,0,.21.17.31.27l9,9c.52.52.52.76,0,1.28l-9,9a2.5,2.5,0,0,1-.23.23.64.64,0,0,1-.91.05.6.6,0,0,1,.05-.91c.79-.81,1.6-1.61,2.4-2.41l6.23-6.22C9.35,10.57,9.47,10.5,9.62,10.38Z"/></g></g></svg>
</template>
<style lang="scss" scoped>
.cls-1{fill:#f1f2f2;stroke:#d1d3d4;stroke-miterlimit:10;stroke-width:0.76px;}
</style>