<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10.33 18.98"><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="0.35 18.63 9.63 9.35 0.63 0.35"/></g></g></svg>
</template>