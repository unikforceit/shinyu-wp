export default [
  {
    label: 'Transportation',
    value: [
      'airport',
      // 'bus_station',
      // 'gas_station',
      'subway_station',
      // 'taxi_stand',
      'train_station'
      // 'transit_station'
    ]
  },
  {
    label: 'Education',
    value: [
      'school'
      // 'library'
    ]
  },
  {
    label: 'Health',
    value: [
      // 'dentist',
      // 'doctor',
      'hospital',
      // 'gym',
      // 'spa',
      'pharmacy'
    ]
  },
  {
    label: 'Entertainment',
    value: [
      // 'beauty_salon',
      // 'art_gallery',
      'department_store',
      // 'clothing_store',
      // 'movie_rental',
      'movie_theater',
      // 'moving_company',
      // 'museum',
      // 'night_club',
      'shopping_mall'
      // 'shoe_store',
      // 'stadium',
      // 'supermarket',
      // 'convenience_store',
      // 'store'
    ]
  },
  {
    label: 'Restaurant',
    value: [
      // 'bakery',
      // 'bar',
      'cafe',
      'restaurant'
      // 'meal_delivery',
      // 'meal_takeaway'
    ]
  },
  {
    label: 'Bank',
    value: [
      // 'accounting',
      'atm',
      'bank'
    ]
  },
  {
    label: 'Park',
    value: [
      // 'aquarium',
      'park',
      'zoo'
    ]
  }
  // {
  //   label: 'Etc',
  //   value: [
  //     'embassy',
  //     'church',
  //     'city_hall',
  //     'police',
  //     'post_office',
  //     'fire_station',
  //     'local_government_office',
  //     'laundry',
  //     'pet_store'
  //   ]
  // }
]
