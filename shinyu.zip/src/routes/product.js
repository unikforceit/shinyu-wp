import ImagesLoaded from 'Imagesloaded'
import Swiper from 'swiper/js/swiper'

export default {
  init() {
    // const form = document.querySelector('.form-add-to-cart')
    const modal = document.querySelector('.modal')
    const modalTitle = document.querySelector('.modal-card-title')
    const modalCloses = document.querySelectorAll('[modal-close]')

    const buyButtons = document.querySelectorAll('.buynow')
    const modalConfirm = document.querySelector('.modal-confirm')

    const formPackage = document.querySelector('.form-package')
    const formProduct = document.querySelector('.form-product')

    const inputProductId = document.querySelector('#input-add-to-cart')
    const inputPackage = document.querySelector('#input-package')

    const radios = document.querySelectorAll('[type="radio"]')

    const html = document.querySelector('html')

    if (buyButtons) {
      buyButtons.forEach((element) => {
        element.onclick = (e) => {
          e.preventDefault()

          const selected = e.currentTarget.dataset.select

          modalConfirm.disabled = true
          modalConfirm.dataset.submit = selected

          radios.forEach((element) => {
            element.checked = false
          })

          if (selected === 'package') {
            inputProductId.value = e.currentTarget.dataset.product_id
            formPackage.classList.remove('d-none')
            formProduct.classList.add('d-none')
            modalTitle.innerHTML = 'เลือกแพ๊จเกจ'
          } else {
            inputPackage.value = e.currentTarget.dataset.package
            formProduct.classList.remove('d-none')
            formPackage.classList.add('d-none')
            modalTitle.innerHTML = 'เลือก Router'
          }

          modal.dataset.content = selected

          modal.classList.add('is-active')
          html.classList.add('modal-show')
        }
      })
    }

    modalCloses.forEach((element) => {
      element.onclick = () => {
        modal.classList.remove('is-active')
        html.classList.remove('modal-show')
      }
    })

    radios.forEach((element) => {
      element.onchange = () => {
        modalConfirm.disabled = false
      }
    })

    modalConfirm.onclick = (e) => {
      e.preventDefault()

      e.currentTarget.classList.add('is-loading')

      const form = e.currentTarget.dataset.submit

      document.querySelector(`.form-${form}`).submit()
    }

    const galleries = document.querySelectorAll('.product-gallery-swiper')

    galleries.forEach((element) => {
      const swiper = new Swiper(element, {
        lazy: {
          loadPrevNext: true,
        },
        autoplay: {
          delay: 4000,
        },
        init: false,
        loop: false,
        effect: 'fade',
        speed: 400,
        autoHeight: true,
        grabCursor: true,
        spaceBetween: 0,
        pagination: {
          el: element.querySelector('.swiper-pagination'),
          clickable: true,
          renderBullet: (index, className) => {
            return `<span class="${className}"><span></span></span>`
          },
        },
      })

      ImagesLoaded(element, () => {
        swiper.init()
      })
    })
  },
  finalize() {},
}
