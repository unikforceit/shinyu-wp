import { Loader } from 'google-maps'
import Vue from 'vue'
import Buefy from 'buefy'
import ContactForm from '../vue/components/ContactForm.vue'

export default {
  init() {
    new Vue({
      el: '.contact-form',
      components: { ContactForm },
    })
    // const loader = new Loader('AIzaSyD4TV_72f8F-IOCMPuMzZjlMKvXsb5Uz6M')
    // const lat = 13.722553143604365
    // const lng = 100.58058164346753
    // loader.load().then(function (google) {
    //   const map = new google.maps.Map(document.getElementById('contact-map'), {
    //     center: { lat, lng },
    //     zoom: 12,
    //   })
    //   const marker = new google.maps.Marker({
    //     map,
    //     draggable: false,
    //     // icon: SHINYU.marker,
    //     position: { lat, lng },
    //   })
    //   google.maps.event.addListener(marker, 'click', () => {
    //     window.open('https://goo.gl/maps/GkyHWj27HtQ6sXPRA')
    //   })
    // })
    // const inputs = document.querySelectorAll('.form-control')
    // for (let index = 0; index < inputs.length; index++) {
    //   const element = inputs[index]
    //   element.addEventListener(
    //     'focus',
    //     (e) => {
    //       e.target.closest('.form-group').classList.add('is-focus')
    //     },
    //     true
    //   )
    //   element.addEventListener(
    //     'blur',
    //     (e) => {
    //       if (!e.target.value) {
    //         e.target.closest('.form-group').classList.remove('is-focus')
    //       }
    //     },
    //     true
    //   )
    // }
  },
  finalize() {},
}
