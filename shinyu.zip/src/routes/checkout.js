import Qs from 'qs'
import axios from 'axios'
import Pristine from 'pristinejs'

let provinceList = {}
let districtList = {}
let subDistrictList = {}

const subDistrict = document.querySelector('#billing_sub_district')
const postcode = document.querySelector('#billing_postcode')
const city = document.querySelector('#billing_city')
const state = document.querySelector('#billing_state')

function getSubDistrictsByZipCode(zipCode) {
  const subDistrictsOption = []
  let optionIndex = 0

  subDistrict.options.length = 0
  subDistrict.options[subDistrict.options.length] = new Option('เลือกตำบล', '')

  subDistrictList.rows.forEach((e, i, array) => {
    if (array[i].zip_code === parseInt(zipCode, 10)) {
      subDistrict.options[subDistrict.options.length] = new Option(
        array[i].name_th,
        array[i].name_th
      )
      optionIndex++
      subDistrict.options[optionIndex].dataset.id = array[i].district_id
    }
  })
}

function fetchAddress() {
  axios
    .post(TOT.ajaxurl, Qs.stringify({ action: 'fetch_address' }))
    .then((response) => {
      provinceList = response.data.provinces
      districtList = response.data.districts
      subDistrictList = response.data.subdistricts
      getSubDistrictsByZipCode(postcode.value)
    })
    .catch((error) => {
      // handle error
      console.log(error)
    })
    .finally(() => {})
}

function validatorField() {
  const event = document.createEvent('HTMLEvents')
  event.initEvent('input', true, false)
  state.dispatchEvent(event)
  city.dispatchEvent(event)
  subDistrict.dispatchEvent(event)
}

function resetField() {
  city.value = ''
  state.value = ''
  validatorField()
}

export default {
  init() {
    fetchAddress()

    postcode.oninput = (e) => {
      resetField()
      getSubDistrictsByZipCode(e.target.value)

      const event = document.createEvent('HTMLEvents')
      event.initEvent('input', true, false)
      billingLocation.dispatchEvent(event)
    }

    subDistrict.onchange = (e) => {
      const selected = e.target.options.selectedIndex
      let subDistrictId = null
      resetField()

      if (selected > -1) {
        subDistrictId = e.target.options[selected].dataset.id
        // subDistrictId = e.target.value

        for (const [i, array] of districtList.rows.entries()) {
          if (array.id === parseInt(subDistrictId, 10)) {
            city.value = array.name_th
            const provinceId = array.province_id

            for (const [i, array] of provinceList.rows.entries()) {
              if (array.id === provinceId) {
                // console.log(array[i].name_th)
                const opts = state.options
                for (let opt, j = 0; (opt = opts[j]); j++) {
                  if (opt.innerHTML === array.name_th) {
                    state.selectedIndex = j
                    break
                  }
                }
                // const event = document.createEvent('HTMLEvents')
                // event.initEvent('change', true, false)
                // state.dispatchEvent(event)
                break
              }
            }
            break
          }
        }
        validatorField()

        // districtList.rows.forEach((e, i, array) => {})
      }
      // console.log(e.target.value)
    }
  },
  finalize() {
    const form = document.querySelector('form.woocommerce-checkout')
    const phone = document.querySelector('#billing_phone')
    // const firstName = document.querySelector('#billing_first_name')

    const pristine = new Pristine(
      form,
      {
        classTo: 'form-row',
        errorClass: 'has-danger',
        successClass: 'has-success',
        errorTextParent: 'form-row',
        errorTextTag: 'div',
        errorTextClass: 'text-help',
      },
      true
    )

    pristine.addValidator(
      phone,
      (value) => {
        const number = new RegExp('[0-9]')
        if (value.match(number) && value.length > 8) {
          return true
        }
        return false
      },
      'รูปแบบหมายเลขโทรศัพท์ไม่ถูกต้อง',
      2,
      false
    )

    form.addEventListener('submit', function (e) {
      // e.preventDefault()
      // check if the form is valid
      const valid = pristine.validate() // returns true or false
      if (!valid) {
        e.preventDefault()
      }
    })
  },
}
