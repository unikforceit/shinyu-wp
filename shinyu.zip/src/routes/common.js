import WebFont from 'webfontloader'
import enterView from 'enter-view'
import imagesLoaded from 'imagesloaded'
import Swiper from 'swiper/bundle'
import MoveTo from 'moveTo'
import Vue from 'vue'
import Buefy from 'buefy'

import Analytics from 'analytics'
import googleTagManager from '@analytics/google-tag-manager'

import Subscribe from '../vue/components/Subscribe.vue'
import compareSelected from '../vue/components/compareSelected.vue'
import TrainStation from '../vue/components/TrainStation.vue'
import SearchBar from '../vue/components/SearchBarStandard.vue'

import store from '../vue/store'

const { body, documentElement } = document
const hamburger = body.querySelector('.hamburger-menu')
const currencies = body.querySelectorAll('.currency-switcher a')

export default {
  init() {
    const setCookie = function setCookie(cname, cvalue, exdays) {
      const d = new Date()
      d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000)
      const expires = `expires=${d.toUTCString()}`
      document.cookie = `${cname}=${cvalue};${expires};path=/`
    }

    const analytics = Analytics({
      app: 'awesome-app',
      plugins: [
        googleTagManager({
          containerId: 'GTM-P9BZDJN',
        }),
      ],
    })

    // analytics.page()

    WebFont.load({
      google: {
        families: [
          'Prompt:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i&display=swap&subset=thai',
        ],
      },
    })

    hamburger.addEventListener('click', (e) => {
      e.preventDefault()
      documentElement.classList.toggle('open-menu')
    })

    Vue.use(Buefy)

    new Vue({
      el: '.subscribe',
      components: { Subscribe },
    })

    new Vue({
      el: '.compare-selected',
      components: { compareSelected },
      store,
    })

    new Vue({
      el: '.train-station',
      components: { TrainStation },
    })

    if (
      !document.body.classList.contains('home') &&
      !document.body.classList.contains('search')
    ) {
      new Vue({
        el: '.search-bar',
        components: { SearchBar },
      })
    }

    const partner = document.querySelector('.partner-swiper-container')
    if (partner) {
      const partnerSwiper = new Swiper(partner, {
        // lazy: {
        //   loadPrevNext: true,
        // },
        lazy: true,
        slidesPerView: 5,
        slidesPerGroup: 5,
        autoplay: {
          delay: 4000,
        },
        init: true,
        loop: false,
        speed: 600,
        autoHeight: true,
        spaceBetween: 32,
        pagination: {
          el: partner.querySelector('.swiper-pagination'),
          clickable: true,
        },
        navigation: {
          nextEl: partner.querySelector('.next'),
          prevEl: partner.querySelector('.prev'),
        },
      })
    }

    const navigation = document.querySelector('.navigation.scrollspy')
    if (navigation) {
      imagesLoaded(document.body, (instance) => {
        const moveTo = new MoveTo({
          tolerance: 58,
          duration: 800,
        })

        const triggers = document.querySelectorAll('.navigation a')
        for (let i = 0; i < triggers.length; i++) {
          moveTo.registerTrigger(triggers[i])
        }

        const sections = document.querySelectorAll('.main-content section')
        const menuLinks = document.querySelectorAll('.navigation a')

        const makeActive = (link) => menuLinks[link].classList.add('active')
        const removeActive = (link) =>
          menuLinks[link].classList.remove('active')

        const removeAllActive = () =>
          [...Array(sections.length).keys()].forEach((link) =>
            removeActive(link)
          )
        const sectionMargin = 0

        let currentActive = 0

        window.addEventListener('scroll', () => {
          const current =
            sections.length -
            [...sections]
              .reverse()
              .findIndex(
                (section) => window.scrollY >= section.offsetTop - sectionMargin
              ) -
            1

          if (current !== currentActive) {
            removeAllActive()
            currentActive = current
            makeActive(current)
          }
        })

        enterView({
          selector: '.navigation',
          enter: (el) => {
            navigation.classList.add('is-sticky')
          },
          offset: 1,
          exit: (el) => {
            navigation.classList.remove('is-sticky')
          },
        })
      })
    }

    currencies.forEach((element) => {
      element.addEventListener('click', (e) => {
        e.preventDefault()
        setCookie('currency', element.dataset.code, 100)
        window.location.reload()
      })
    })
  },
  finalize() {
    // const socialItem = document.querySelectorAll('.social li')
    // socialItem.forEach((element) => {
    //   element.addEventListener('mouseover', (event) => {
    //     element.querySelector('.tooltip-content').add('is-hover')
    //   })
    //   element.addEventListener('mouseout', (event) => {
    //     element.querySelector('.tooltip-content').remove('is-hover')
    //   })
    // })

    // window.onload = () => {
    //   const pdpa = document.querySelector('.pdpa-consent')
    //   if (pdpa) {
    //     gsap.to(pdpa, 0.3, {
    //       height: pdpa.querySelector('.section').scrollHeight,
    //     })
    //   }
    // }

    if (
      !body.classList.contains('search') &&
      !body.classList.contains('page-template-template-about') &&
      !body.classList.contains('single-room')
    ) {
      // element
      imagesLoaded(document.body, (instance) => {
        // enterView({
        //   selector: '.main-content',
        //   enter: (el) => {
        //     body.classList.add('header-sticky')
        //   },
        //   offset: 1,
        //   exit: (el) => {
        //     body.classList.remove('header-sticky')
        //   },
        // })

        let scrollPos = 0
        let timeout

        window.addEventListener('scroll', () => {
          // if (body.scrollHeight < 2000) return
          // console.log(body.getBoundingClientRect().top)

          if (body.getBoundingClientRect().top < 0) {
            body.classList.add('header-hide')
            body.classList.add('header-sticky')
          } else {
            body.classList.remove('header-hide')
            body.classList.remove('header-sticky')
          }

          if (body.getBoundingClientRect().top > scrollPos) {
            body.classList.add('scrollup')
          } else if (body.getBoundingClientRect().top < scrollPos) {
            body.classList.remove('scrollup')
          }

          clearTimeout(timeout)

          timeout = setTimeout(function () {
            scrollPos = body.getBoundingClientRect().top
          }, 100)

          // console.log(scrollPos)
        })
      })
    } else {
      const searchBar = body.querySelector('.search-bar')
      window.addEventListener('scroll', () => {
        if (body.getBoundingClientRect().top < -83) {
          searchBar.classList.add('is-sticky')
        } else {
          searchBar.classList.remove('is-sticky')
        }
      })
    }
  },
}
