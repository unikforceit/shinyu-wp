
<?php get_header(); ?>
  <section class="search-bar is-relative"><search-bar></search-bar></section>
  <section class="page-header">
    <div class="container">
      <h1 class="page-title"><?php pll_e('Promotion') ?></h1>
      <?php the_breadcrumb(); ?>
      <p class="page-description">Shinyu Real Estate คือเพื่อนสนิทที่ตอบโจทย์คุณ ด้วยความ เชี่ยวชาญ ทาง ด้านการลุงทุน <br> อสังหาทรัพย์ที่มีความเชี่ยวชาญ ทั้งตลาดในไทยและ ต่างประเทศ Shinyu Real Estate</p>
    </div>
  </section><!-- .page-header -->
	<main class="main-content">
    <div class="container">
      <?php if ( have_posts() ) : ?>
        <div class="columns is-multiline">
          <?php while ( have_posts() ) : the_post();  ?>
            <div class="column is-6 promotion-col">
              <figure class="promotion-item">
                <a href="<?php the_permalink(); ?>" class="promotion-thumbnail">
                  <?php
                    if (has_post_thumbnail()) : echo get_the_post_thumbnail(get_the_ID(), 'thumb-promotion');
                    else : echo "<img src='https://via.placeholder.com/552x245/FFFF00/000000'>";
                    endif
                  ?>
                </a>
                <figcaption class="d-flex align-items-start flex-column promotion-caption">
                  <h4 class="promotion-title"><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h4>
                </figcaption>
              </figure>
            </div>
          <?php endwhile; ?>
        </div>
      <?php endif ?>
    </div>
  </main>
<?php get_footer(); ?>
