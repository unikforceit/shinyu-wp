<?php 

add_action('wp_enqueue_scripts', function() {
  $custom_css = '.page-header, .search-header{background-image:url('. content_url('uploads/2020/12/page-header-bg.jpg') .') }';
  $custom_css .= '.service-background{background-image:url('. content_url('uploads/2020/12/service-bg.jpg') .') }';
  $custom_css .= '.search-box, .search-bar{background-image:url('. content_url('uploads/2020/12/search-bg.jpg') .') }';
  $custom_css .= '.fullscreen-navigation{background-image:url('. content_url('uploads/2021/01/menu-bg.jpg') .') }';
  $custom_css .= '.unit-registration{background-image:url('. content_url('uploads/2021/01/registration-bg.jpg') .') }';
  wp_add_inline_style(THEME_SLUG , minify_css($custom_css));
}, 100);
