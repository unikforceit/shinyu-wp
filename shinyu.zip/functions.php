<?php
/*-----------------------------------------------------------------------------------*/
/*  Define Theme Vars
/*-----------------------------------------------------------------------------------*/

define('THEME_DIR', trailingslashit(get_template_directory()));
define('THEME_URI', trailingslashit(get_template_directory_uri()));
define('THEME_NAME', 'Shinyu');
define('THEME_SLUG', 'syrs');
define('THEME_VERSION', '0.2.8');
define('SRC_URI', THEME_URI . 'src');
define('STATIC_URI', THEME_URI . 'static');
define('INC_DIR', THEME_DIR . 'inc');
define('IMG_URI', STATIC_URI . '/images/');
define('CURRENCY', isset($_COOKIE['currency']) ? $_COOKIE['currency'] : 'THB');

define('PAGE_ID_SEARCH', pll_get_post(get_page_by_path('search')->ID));
define('PAGE_ID_CONTACT', pll_get_post(get_page_by_path('contact-us')->ID));
define('PAGE_ID_POST_PROPERTY', pll_get_post(get_page_by_path('post-property')->ID));
define('PAGE_ID_ABOUT', pll_get_post(get_page_by_path('about-us')->ID));
define('PAGE_ID_COMPARE', pll_get_post(get_page_by_path('compare')->ID));
define('PAGE_ID_CALCULATOR', pll_get_post(get_page_by_path('calculator')->ID));
define('PAGE_ID_STATISTICS', pll_get_post(get_page_by_path('statistics')->ID));
define('PAGE_ID_SITEMAP', pll_get_post(get_page_by_path('sitemap')->ID));

array_map(function($file) {
	require_once THEME_DIR . 'app/'. $file .'.php';
}, [
	'helpers',
	'functions',
	'enqueue-scripts',
	'setup',
	'cleanup',
	'sidebar',
	'menu',
	'branding',
	'theme-customizer',
	'breadcrumb'
]);

require INC_DIR . '/lib/class-ds-wp-breadcrumb.php';

require INC_DIR . '/helpers.php';
require INC_DIR . '/class/class-video.php';
require INC_DIR . '/class/class-email.php';
require INC_DIR . '/class/class-contact-us.php';
// require INC_DIR . '/class/class-page-service.php';
require INC_DIR . '/class/class-project.php';
// require INC_DIR . '/class/class-project-landing-page.php';
require INC_DIR . '/class/class-unit.php';
require INC_DIR . '/class/class-promotion.php';
require INC_DIR . '/class/class-article.php';
require INC_DIR . '/class/class-service.php';
require INC_DIR . '/class/class-partner.php';
require INC_DIR . '/class/class-testimonial.php';
// require INC_DIR . '/class/class-job.php';
require INC_DIR . '/class/class-form.php';
// require INC_DIR . '/class/form/class-post-property.php';

require INC_DIR . '/class/class-page-home.php';
require INC_DIR . '/class/class-page-about-us.php';

// require INC_DIR . '/class/class-social.php';
require INC_DIR . '/class/class-currencies.php';
// require INC_DIR . '/icons.php';
require INC_DIR . '/strings-translations.php';

require INC_DIR . '/api/api-unit-recommended.php';
require INC_DIR . '/api/api-unit-special.php';
require INC_DIR . '/api/api-unit-search.php';
require INC_DIR . '/api/api-room-tag.php';
require INC_DIR . '/api/api-project-area-search.php';
require INC_DIR . '/api/api-project-search.php';
require INC_DIR . '/api/api-uploadimage.php';
require INC_DIR . '/api/api-post-property.php';

add_action('wp_enqueue_scripts', function() {

	wp_deregister_script('jquery');
	wp_dequeue_style('wp-block-library');
	wp_dequeue_style('wp-block-library-theme');
	wp_dequeue_style('wc-block-style');

  $manifest = json_decode(file_get_contents('build/assets.json', true));
	$front    = $manifest->front;

	wp_enqueue_style(THEME_SLUG, THEME_URI . 'build/' . $front->css, [], THEME_VERSION, 'all');
	wp_enqueue_script(THEME_SLUG, THEME_URI . 'build/' . $front->js, [], THEME_VERSION, true);
  wp_localize_script(THEME_SLUG, 'SHINYU', array(
		'ajaxurl'         => admin_url( 'admin-ajax.php' ),
		'api_endpoint'    => get_rest_url(),
		'search_url'      => get_permalink(PAGE_ID_SEARCH),
		'compare_url'     => get_permalink(PAGE_ID_COMPARE),
		'static_uri'      => STATIC_URI,
		'marker'          => STATIC_URI . '/icons/marker.svg',
		'field'           => unit_fields(['lang' => get_locale()]),
		'i18n'            => require INC_DIR . '/i18n.php',
		'lang'            => get_locale(),
		'max_upload_size' => wp_max_upload_size(),
		'currency'        => [
			'code' =>	CURRENCY,
			'unit' => get_currency_by_code(CURRENCY),
		],
	));
}, 99);

add_action('admin_enqueue_scripts', function() {

  $manifest = json_decode(file_get_contents('build/assets.json', true));
	$admin    = $manifest->admin;
	wp_enqueue_style(THEME_SLUG, THEME_URI . 'build/' . $admin->css, array(), THEME_VERSION, 'all');

}, 9999);

// Add page slug to body class, love this - Credit: Starkers Wordpress Theme
add_filter('body_class', function($classes) {
	global $post;

	if (is_home()) {
		$key = array_search('blog', $classes);
		// if ($key > -1) {
		// 	unset($classes[$key]);
		// }
		$classes[] = 'page';
	} elseif (is_singular()) {
		if ($post->post_parent) {
			$classes[] =  'parent-' . get_post_field( 'post_name', $post->post_parent);
		}
		
		$classes[] = sanitize_html_class($post->post_name);
	}
	return $classes;
});

add_filter( 'wp_title', function($title) {
  return html_entity_decode($title);
}, 10, 2);


add_filter( 'excerpt_length', function($length) {
  return 100;
}, 999);


add_filter( 'excerpt_more', function($length) {
  return ' ...';
});

add_filter( 'rest_url_prefix', function() {
  return 'api';
});


add_filter( 'rest_endpoints', function($endpoints) {
  $endpoints_to_remove = array(
    'mediadd',
    'types',
    'statuses',
    'taxonomies',
    'tags',
    'users',
    'comments',
    'settings',
    'themes',
    'blocks',
    'oembed',
    'posts',
    'pages',
    'block-renderer',
    'search',
    'categories'
  );

  foreach ( $endpoints_to_remove as $endpoint ) {
    $base_endpoint = "/wp/v2/{$endpoint}";
    foreach ( $endpoints as $maybe_endpoint => $object ) {
      if ( strpos( $maybe_endpoint, $base_endpoint ) !== false ) {
        unset( $endpoints[ $maybe_endpoint ] );
      }
    }
  }

  unset($endpoints['/oembed/1.0']);
  unset($endpoints['/oembed/1.0/embed']);
  unset($endpoints['/oembed/1.0/proxy']);
  unset($endpoints['/wp/v2']);  
  unset($endpoints['/']);

  return $endpoints;
});

add_filter('query_vars', function($qvars) {
	$qvars[] = 'transaction';
	$qvars[] = 'section';
	return $qvars;
});

add_filter('init', function(){
	if (!isset($_COOKIE['currency'])) {
		setcookie('currency', 'THB', time() + 31556926); 
	}
}, 10, 2);


add_filter('posts_search', function($search, $wp_query){
	global $wpdb;
 
	if (empty($search)) return $search;

	$q = $wp_query->query_vars;    
	$n = ! empty( $q['exact'] ) ? '' : '%';

	$search = '';
	$searchand = '';

	foreach ( (array) $q['search_terms'] as $term ) {
		$term = esc_sql($wpdb->esc_like($term));
		$search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
		$searchand = ' AND ';
	}

	if (!empty($search)) {
		$search = " AND ({$search}) ";
	
		if (!is_user_logged_in())
			$search .= " AND ($wpdb->posts.post_password = '') ";
	}

	return $search;

}, 10, 2);


add_filter('init', function(){
	if (!is_user_logged_in() && $GLOBALS['pagenow'] !== 'wp-login.php') { ?>
		<style>
		@import url('https://fonts.googleapis.com/css2?family=Prompt:wght@400;500&display=swap');
		</style>
		<div style="font-family: 'Prompt', sans-serif; position: absolute;	top: 50%;	left: 50%;transform: translate(-50%, -50%)">
			<center style="font-size: 30px">
			<img src="<?php echo content_url('uploads/2020/12/logo.png') ?>" alt="">
			<p style="margin-bottom: 0">ปิดปรับปรุงและอัพเดทระบบชั่วคราว</p>
			<small>System Maintenance and update</small>
			</center>
		</div>
		<?php exit();
	}
	
});
