<?php 
  wp_redirect(get_permalink(get_page_by_path('search'))); exit;