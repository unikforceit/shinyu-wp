<?php get_header();  ?>
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">404 Not found</h1>
    </div>
  </section><!-- .page-header -->
<?php get_footer(); ?>
